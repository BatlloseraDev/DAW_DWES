<?php


use App\Http\Controllers\ControladorEjercicio2;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');
//php artisan serve --port 8080

Route::get("/contarLetras", [ControladorEjercicio2::class,'contarLetras']);
Route::get('/cesar', [ControladorEjercicio2::class, 'cesar']);
Route::get('/contarPalabras', [ControladorEjercicio2::class,'contarPalabras']);
Route::get('/palindromo', [ControladorEjercicio2::class,'palindromo']);
Route::get('/anagrama', [ControladorEjercicio2::class,'anagrama']);

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControladorEjercicio2 extends Controller
{
    function contarLetras(Request $request){
        $cadena= strtolower($request->get("cad"));
        $caracter = strtolower($request->get("car"));
        $contador = 0;

        for($i= 0; $i < strlen($cadena); $i++){
            if($caracter == $cadena[$i]){
                $contador++;
            }
        }
        return response()->json(["Resultado"=>"El carácter $caracter aparece $contador veces en la cadena $cadena"]);
    }


    function cesar(Request $request){
        $cadena= strtoupper($request->get("cadena"));
        $cadenaNueva = "";

        for($i= 0; $i < strlen($cadena); $i++){
            //echo json_encode(["".$cadena[$i]=>"".ord($cadena[$i])]);

            if(ord($cadena[$i]) == 32){//espacio
                $cadenaNueva .=$cadena[$i];
            }else if(ord($cadena[$i]) == 90){//z
                $cadenaNueva .=chr(65);
            }else if(ord($cadena[$i]) == 57){//9
                $cadenaNueva .=chr(48);
            }else{
                $cadenaNueva .=chr(ord($cadena[$i])+1);
            }

        }
        return response()->json(["Resultado"=> "$cadenaNueva"]);
    }

    function contarPalabras(Request $request)
    {

        $contarPalabras = str_word_count($request->get("cadena"));

        return response()->json(["Resultado"=> "La frase introducida tiene $contarPalabras palabras"]);

    }

    function palindromo(Request $request)
    {
        $cadena = $request->get("cadena");
        $cadenaNueva = "";

        for($i=strlen($cadena)-1; $i >= 0; $i--){

            $cadenaNueva .=$cadena[$i];

        }
        if($cadena == $cadenaNueva){
            return response()->json(["Resultado"=> "La palabra $cadena es un palíndromo"]);
        }else{
            return response()->json(["Resultado"=> "La palabra $cadena no es un palíndromo"]);
        }
    }

    function anagrama(Request $request){
        $cadena = $request->get("cadena1");
        $cadena2 = $request->get("cadena2");
        $cadenaNueva = "";
        for($i=strlen($cadena)-1; $i >= 0; $i--){

            $cadenaNueva .=$cadena[$i];

        }
        if($cadenaNueva == $cadena2){
            return response()->json(["Resultado"=> "Las cadenas son anagramas"]);
        }else{
            return response()->json(["Resultado"=> "Las cadenas no son anagramas"]);
        }

    }
}

# Laravel_Inicial_Ejercicio2
El ejercicio 2 de laravel
